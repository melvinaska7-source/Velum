package pyvelum.events.window;

import lombok.Generated;
import velum.client.IiIIIIIi_Class66;

public class ContainerReleaseEvent
extends IiIIIIIi_Class66 {
    private final float x;
    private final float y;
    private final int button;

    @Generated
    public float getX() {
        return this.x;
    }

    @Generated
    public float getY() {
        return this.y;
    }

    @Generated
    public int getButton() {
        return this.button;
    }

    @Generated
    public ContainerReleaseEvent(float f, float f2, int n) {
        this.x = f;
        this.y = f2;
        this.button = n;
    }
}

