package velum.client;

import net.minecraft.item.Items;
import velum.client.iIIiIIii_Class148;
import velum.client.iIiIIIii_Class164;
import velum.client.iIiIIiIi_Class166;

public class iIiIiiII_Class173
extends iIiIIIii_Class164 {
    public iIiIiiII_Class173() {
        super("modules.settings.assist.aura", Items.PHANTOM_MEMBRANE.getDefaultStack(), iIIiIIii_Class148.i_field_88b781);
    }

    @Override
    public boolean I_method_75fee910() {
        return iIiIIiIi_Class166.i_method_d56ba8b0();
    }
}

