package velum.client;

import java.net.MalformedURLException;
import java.net.URL;
import velum.client.iiiiii_Class64;

public class IIIIIiI_Class3
extends iiiiii_Class64 {
    public IIIIIiI_Class3(String string) throws MalformedURLException {
        super("HEAD", string);
    }

    public IIIIIiI_Class3(URL uRL) {
        super("HEAD", uRL);
    }
}

