package velum.client;

import net.minecraft.item.Items;
import velum.client.iIIiIIii_Class148;
import velum.client.iIiIIIii_Class164;
import velum.client.iIiIIiIi_Class166;

public class iIiIiIii_Class172
extends iIiIIIii_Class164 {
    public iIiIiIii_Class172() {
        super("modules.settings.assist.boom_trap", Items.PRISMARINE_SHARD.getDefaultStack(), iIIiIIii_Class148.i_field_88b781);
    }

    @Override
    public boolean I_method_75fee910() {
        return iIiIIiIi_Class166.Ii_method_d663fff9();
    }
}

